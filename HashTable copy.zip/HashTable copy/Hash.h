/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Hash.h
 * Author: Prince
 *
 * Created on March 9, 2018, 1:43 PM
 */

#ifndef HASH_H
#define HASH_H
#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

class Hash{
    
public:
    Hash();
    int hash(string key);
    void AddItem(string name, string drink);
    int NumberOfItemsinIndex(int index);
    void PrintTable();
    void PrintItemsinIndex(int index);
    void FindDrink(string name);
    void RemoveItem(string name);
    
private:
    static const int tablesize = 4;
    
    struct item {
        
        string name;
        string drink;
        item* next;
    };
    
    item* hashTable[tablesize];
};


#endif /* HASH_H */

