/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Prince
 *
 * Created on March 9, 2018, 1:40 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include "Hash.h"

using namespace std;


int main(int argc, char** argv) {
    
    
    Hash hashy;
    string name = "";
    
    
    hashy.AddItem("Prince", "Pepsi");
    hashy.AddItem("Paul", "margarita");
    hashy.AddItem("Janice", "Cool Aid");
    hashy.AddItem("Annette", "Dr. Pepper");
    hashy.AddItem("James", "Lemonade");
    hashy.AddItem("John", "Water");
    hashy.AddItem("Jacob", "Sprite");
    hashy.AddItem("Mike", "Coke");
    hashy.AddItem("Tina", "Tampico");
    hashy.AddItem("Steven", "Hawaii Punch");
    
    //hashy.PrintTable();
    
    //hashy.PrintItemsinIndex(3);
    
    /* while(name != "exit"){
        cout << "Search for : ";
        cin >> name;
        if (name != "exit"){
            hashy.FindDrink(name);
        }
     
     */
    
   hashy.PrintItemsinIndex(3);
    
    while(name != "exit"){
        cout << "Remove : ";
        cin >> name;
        if (name != "exit"){
            hashy.RemoveItem(name);
        }
             
    }
 
    hashy.PrintItemsinIndex(3);
    
    return 0;
}

