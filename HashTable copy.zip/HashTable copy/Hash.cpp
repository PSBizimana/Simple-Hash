/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <cstdlib>
#include <iostream>
#include <string>

#include "Hash.h"

using namespace std;

Hash::Hash(){
    
    for(int i = 0; i<tablesize; i++){
        
        hashTable[i] = new item;
        hashTable[i]->name = "empty";
        hashTable[i]->drink = "empty";
        hashTable[i]->next= NULL;
        
    }
    
}

void Hash::AddItem(string name, string drink){
    
    int index = hash(name);
    
    if(hashTable[index]->name == "empty"){
        
        hashTable[index]->name = name;
        hashTable[index]->drink = drink;
    }
    
    else {
        
        item* Ptr = hashTable[index];
        item* n = new item; 
        
        n->name = name;
        n->drink = drink;
        n->next = NULL;
        
        while(Ptr->next != NULL)
        {
            
            Ptr = Ptr->next;
        }
        Ptr->next = n;
        
    }
}


int Hash::NumberOfItemsinIndex(int index){
    
    int count = 0;
    
    if(hashTable[index]->name == "empty"){
        
        return count;
    }
    else{
        
        count++;
        item* Ptr = hashTable[index];
        while(Ptr->next != NULL)
        {
            count++;
            Ptr = Ptr->next;
        }
        return count;
    }
    
}

void Hash::PrintTable(){
    
    int number;
    for(int i = 0; i<tablesize; i++){
        
        number = NumberOfItemsinIndex(i);
        cout<< "----------------------\n";
        cout<< "index = " << i << endl;
        cout<< hashTable[i]->name << endl;
        cout<< hashTable[i]->drink<< endl;
        cout<< "Number of Items: " << number << endl; 
        cout<< "----------------------\n";
        
    }
}


void Hash::PrintItemsinIndex(int index){
    
    item* Ptr = hashTable[index];
    
    if (Ptr->name == "empty"){
        
        cout << "index =  " << index << " is empty.";
        
    }
    
    else {
        
        cout << "index " << index << " contains the following items\n";
        
        while(Ptr != NULL){
            cout<< "------------\n";
            cout<< Ptr->name <<endl;
            cout<< Ptr->drink <<endl;
            cout<< "------------\n";
            Ptr= Ptr->next;
            
        }
        
    }
}

void Hash::FindDrink(string name){
    
    int bucket = hash(name);
    bool foundName = false;
    string drink;
    
    item* Ptr = hashTable[bucket];
    while (Ptr != NULL){
        
        if(Ptr->name == name){
        foundName = true;
        drink = Ptr->drink; 
        }
        Ptr = Ptr->next;
    }
    
    if(foundName == true)
    {
        
        cout << "Favorite Drink is: " << drink << endl;
        
    }
    
    else{
        
        cout << name << "'s info was not found in the HashTable" << endl;
    }
    
}

int Hash::hash(string key){
    
    int hash = 0;
    int index;
   
    
    for(int i=0; i < key.length(); i++)
    {
        
        hash = hash + (int)key[i];
    }
    
    index = hash % tablesize;
    
    
    
    return index;
    
}

void Hash::RemoveItem(string name){
    
    int index = hash(name);
    
    item* delPtr;
    item* p1;
    item* p2;
    
    //case 0 - bucket is empty
            
    if(hashTable[index]->name == "empty" && hashTable[index]->drink == "empty"){
        
        cout << name << " could not be found in the table\n";
    }
    
    //case 1 - only 1 item contained in bucket and item has matching name
        
    else if(hashTable[index]->name == name && hashTable[index]->next == NULL){
        
        hashTable[index]->name = "empty";
        hashTable[index]->drink = "empty";
        
        cout << name << " was deleted from the Hash Table\n";
    }
    
    //case 2 - There is a match is first item but there are more items in bucket.
      
    else if(hashTable[index]->name == name){
        
        delPtr = hashTable[index];
        hashTable[index] = hashTable[index]->next;
        delete delPtr;
        
        cout << name << " was removed from the Hash Table\n";
    }
    
    //case 3 - Bucket Contains items but first item is not a match
    else{
        
        p1 = hashTable[index]->next;
        p2 = hashTable[index];
        
        while(p1 != NULL && p1->name != name ){
            
            p2 = p1;
            p1 = p1->next;
        }
        //case 3.1 - No match
        if(p1 == NULL){
            
            cout << name << " could not be found in the table\n";
        }
        //case 3.2 - Match is found
        else{
            
            delPtr = p1;
            p1 = p1->next;
            p2->next = p1;
            
            delete delPtr;
            cout << name << " was removed from the Hash Table\n";
        }
        
        
    }
    
    
    
    
}